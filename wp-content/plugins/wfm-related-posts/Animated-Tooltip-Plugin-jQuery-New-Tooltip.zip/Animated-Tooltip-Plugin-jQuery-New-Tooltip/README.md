# simple Tooltip class
